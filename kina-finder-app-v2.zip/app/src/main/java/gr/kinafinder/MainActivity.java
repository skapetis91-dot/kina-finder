package gr.kinafinder;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final int PICK = 7;
    WebView web;
    SharedPreferences prefs;
    ValueCallback<Uri[]> fileCb;
    String pendingShare;
    boolean ready;
    final ExecutorService pool = Executors.newCachedThreadPool();
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("kf", Context.MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF141517);
        web = new WebView(this);
        web.setBackgroundColor(0xFF141517);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                }
                return ins;
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("file:")) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                ready = true;
                flushShare();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Φωτογραφία"), PICK);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        setContentView(root);
        handleIntent(getIntent());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || fileCb == null) return;
        Uri u = (res == RESULT_OK && data != null) ? data.getData() : null;
        fileCb.onReceiveValue(u == null ? null : new Uri[]{u});
        fileCb = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String handled) {
                if (!"true".equals(handled)) finish();
            }
        });
    }

    void openExternal(String u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception ignored) {
        }
    }

    // ---- Κοινοποίηση από άλλες εφαρμογές ----
    void handleIntent(final Intent it) {
        if (it == null || !Intent.ACTION_SEND.equals(it.getAction())) return;
        pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject o = new JSONObject();
                    String type = it.getType();
                    Uri u = it.getParcelableExtra(Intent.EXTRA_STREAM);
                    if (u != null && type != null && type.startsWith("image/")) {
                        byte[] j = toJpeg(readUri(u), 1400);
                        o.put("imageB64", Base64.getEncoder().encodeToString(j));
                    } else {
                        String t = it.getStringExtra(Intent.EXTRA_TEXT);
                        if (t == null) return;
                        o.put("url", t);
                    }
                    final String js = o.toString();
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            pendingShare = js;
                            flushShare();
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        });
    }

    void flushShare() {
        if (ready && pendingShare != null) {
            web.evaluateJavascript("window.onShared(" + pendingShare + ")", null);
            pendingShare = null;
        }
    }

    byte[] readUri(Uri u) throws Exception {
        InputStream in = getContentResolver().openInputStream(u);
        if (in == null) throw new Exception("Δεν άνοιξε η φωτογραφία.");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    /** Μικραίνει οποιαδήποτε εικόνα σε JPEG με μέγιστη πλευρά maxSide. */
    byte[] toJpeg(byte[] raw, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) throw new Exception("Η εικόνα δεν διαβάζεται.");
        int ss = 1;
        while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = ss;
        Bitmap b = BitmapFactory.decodeByteArray(raw, 0, raw.length, o2);
        if (b == null) throw new Exception("Η εικόνα δεν διαβάζεται.");
        float sc = Math.min(1f, (float) maxSide / Math.max(b.getWidth(), b.getHeight()));
        int w = Math.max(1, Math.round(b.getWidth() * sc)), h = Math.max(1, Math.round(b.getHeight() * sc));
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.WHITE);
        Bitmap scaled = (w == b.getWidth() && h == b.getHeight()) ? b : Bitmap.createScaledBitmap(b, w, h, true);
        c.drawBitmap(scaled, 0f, 0f, null);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        return bo.toByteArray();
    }

    // ---- Γέφυρα προς τη σελίδα ----
    class Bridge {
        @JavascriptInterface
        public String getPref(String k) {
            return prefs.getString(k, "");
        }

        @JavascriptInterface
        public void setPref(String k, String v) {
            prefs.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public String clipboard() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                if (d == null || d.getItemCount() == 0) return "";
                CharSequence t = d.getItemAt(0).coerceToText(MainActivity.this);
                return t == null ? "" : t.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void open(final String u) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    openExternal(u);
                }
            });
        }

        @JavascriptInterface
        public void analyze(final String payload, final String id) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    String res;
                    try {
                        Engine e = new Engine(getPref("anthropic"), getPref("apify"), new Engine.ImageTool() {
                            @Override
                            public byte[] toJpeg(byte[] data, int maxSide) throws Exception {
                                return MainActivity.this.toJpeg(data, maxSide);
                            }
                        });
                        JSONObject r = e.analyze(new JSONObject(payload));
                        res = new JSONObject().put("ok", true).put("data", r).toString();
                    } catch (Throwable t) {
                        String m = t.getMessage() == null ? t.toString() : t.getMessage();
                        if (t instanceof java.net.UnknownHostException) m = "Δεν υπάρχει σύνδεση στο ίντερνετ.";
                        if (t instanceof java.net.SocketTimeoutException) m = "Άργησε πολύ η απάντηση. Ξαναδοκίμασε.";
                        try {
                            res = new JSONObject().put("ok", false).put("error", m).toString();
                        } catch (Exception x) {
                            res = "{\"ok\":false,\"error\":\"Σφάλμα\"}";
                        }
                    }
                    final String js = "window.__done(" + JSONObject.quote(id) + "," + res + ")";
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript(js, null);
                        }
                    });
                }
            });
        }
    }
}
