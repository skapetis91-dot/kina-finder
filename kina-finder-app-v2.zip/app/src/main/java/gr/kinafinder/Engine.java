package gr.kinafinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Όλη η «δουλειά»: link/φωτογραφία -> AI -> αναζήτηση 1688 -> αποτελέσματα. */
public class Engine {

    public interface ImageTool {
        byte[] toJpeg(byte[] data, int maxSide) throws Exception;
    }

    static final String UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36";
    static final String MODEL = "claude-haiku-5-5";
    static final String ACTOR = "dev00~alibaba-1688-aliexpress-reverse-image-search-api";
    static final int MAX_RESULTS = 8;

    static final String[] BRANDS = {
        "nike", "耐克", "adidas", "阿迪", "puma", "彪马", "gucci", "古驰", "louis vuitton", "lv",
        "路易威登", "prada", "普拉达", "chanel", "香奈儿", "dior", "迪奥", "balenciaga", "巴黎世家",
        "the north face", "north face", "北面", "moncler", "蒙口", "supreme", "stone island", "石头岛",
        "zara", "h&m", "levi", "李维斯", "ralph lauren", "拉夫劳伦", "lacoste", "鳄鱼",
        "tommy hilfiger", "calvin klein", "armani", "阿玛尼", "versace", "范思哲", "burberry",
        "巴宝莉", "hermes", "爱马仕", "fendi", "芬迪", "new balance", "新百伦", "asics", "亚瑟士",
        "under armour", "安德玛", "jordan", "yeezy", "off-white", "canada goose", "加拿大鹅",
        "arc'teryx", "arcteryx", "始祖鸟", "carhartt", "卡哈特", "airpods", "iphone",
        "rolex", "劳力士", "casio", "卡西欧", "大牌", "原单", "复刻", "高仿", "1:1"
    };

    final String aiKey, apifyToken;
    final ImageTool img;
    final JSONObject dbg = new JSONObject();

    void d(String k, Object v) {
        try { dbg.put(k, v); } catch (Exception ignored) { }
    }

    public Engine(String aiKey, String apifyToken, ImageTool img) {
        this.aiKey = aiKey == null ? "" : aiKey.trim();
        this.apifyToken = apifyToken == null ? "" : apifyToken.trim();
        this.img = img;
    }

    // ---------------- HTTP ----------------
    static class Resp {
        int code;
        byte[] body = new byte[0];
        String type = "";
        String text() { return new String(body, StandardCharsets.UTF_8); }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    static Resp http(String method, String url, byte[] body, Map<String, String> headers, int timeoutMs) throws IOException {
        String cur = url;
        for (int hop = 0; hop < 5; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(timeoutMs);
            c.setRequestMethod(method);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept-Language", "el-GR,el;q=0.9,en;q=0.8");
            if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            if (body != null) {
                c.setDoOutput(true);
                OutputStream o = c.getOutputStream();
                o.write(body);
                o.close();
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && body == null) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) break;
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            Resp r = new Resp();
            r.code = code;
            r.type = c.getContentType() == null ? "" : c.getContentType();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) r.body = readAll(in);
            c.disconnect();
            return r;
        }
        throw new IOException("Πάρα πολλές ανακατευθύνσεις.");
    }

    static Map<String, String> hdr(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    static String unescapeHtml(String s) {
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&#x2F;", "/").replace("&lt;", "<").replace("&gt;", ">").replace("\\/", "/");
    }

    // ---------------- Εικόνα από link ----------------
    static final Pattern IMG_EXT = Pattern.compile("\\.(jpe?g|png|webp|gif|avif)(\\?|$)", Pattern.CASE_INSENSITIVE);

    /** Επιστρέφει {imageUrl, pageTitle}. */
    String[] imageFromLink(String link) throws Exception {
        Matcher gm = Pattern.compile("[?&]imgurl=([^&]+)").matcher(link);
        if (gm.find()) return new String[]{URLDecoder.decode(gm.group(1), "UTF-8"), null};
        String path = new URL(link).getPath();
        if (IMG_EXT.matcher(path).find()) return new String[]{link, null};
        Resp r = http("GET", link, null, hdr("Accept", "text/html,image/*"), 25000);
        if (r.type.startsWith("image/")) return new String[]{link, null};
        if (r.code >= 400) throw new Exception("Το site δεν άφησε να διαβαστεί η σελίδα (" + r.code + "). Κάνε screenshot και ανέβασέ το.");
        String page = r.text();
        String title = null;
        Matcher tm = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(page);
        if (tm.find()) {
            title = unescapeHtml(tm.group(1)).trim();
            if (title.length() > 200) title = title.substring(0, 200);
        }
        String[] pats = {
            "<meta[^>]+property=[\"']og:image(?::secure_url)?[\"'][^>]+content=[\"']([^\"']+)",
            "<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']og:image",
            "<meta[^>]+name=[\"']twitter:image[\"'][^>]+content=[\"']([^\"']+)",
            "\"image\"\\s*:\\s*\"(https?:[^\"]+)\"",
            "\"image\"\\s*:\\s*\\[\\s*\"(https?:[^\"]+)\""
        };
        for (String p : pats) {
            Matcher m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(page);
            if (m.find()) return new String[]{new URL(new URL(link), unescapeHtml(m.group(1))).toString(), title};
        }
        throw new Exception("Δεν βρήκα φωτογραφία προϊόντος σε αυτό το link. Κάνε screenshot και ανέβασέ το.");
    }

    // ---------------- AI ----------------
    static final String AI_PROMPT = "Είσαι βοηθός αγορών. Δες τη φωτογραφία προϊόντος. Απάντησε ΜΟΝΟ με ένα αντικείμενο JSON, χωρίς markdown και χωρίς άλλο κείμενο, με ακριβώς αυτά τα κλειδιά:\n"
        + "{\"what_el\":\"σύντομη περιγραφή στα ελληνικά (π.χ. Μαύρη βαμβακερή ζακέτα με κουκούλα και φερμουάρ)\","
        + "\"query_zh\":\"λέξεις αναζήτησης στα κινέζικα χωρίς μάρκα\","
        + "\"category\":\"ένα από: clothes, shoes, bags, electronics, phone_pc, toys, watches, moto, tools, home, other\","
        + "\"weight_kg\":αριθμός (βάρος ενός τεμαχίου με συσκευασία),"
        + "\"brand\":\"μάρκα αν φαίνεται λογότυπο ή είναι γνωστό επώνυμο σχέδιο, αλλιώς κενό\","
        + "\"logo_visible\":true/false}\n"
        + "Πληροφορία από τη σελίδα (μπορεί να λείπει): ";

    String claude(JSONArray content, int maxTokens) throws Exception {
        JSONObject msg = new JSONObject().put("role", "user").put("content", content);
        JSONObject body = new JSONObject().put("model", MODEL).put("max_tokens", maxTokens)
                .put("messages", new JSONArray().put(msg));
        Resp r = http("POST", "https://api.anthropic.com/v1/messages", body.toString().getBytes(StandardCharsets.UTF_8),
                hdr("x-api-key", aiKey, "anthropic-version", "2023-06-01", "content-type", "application/json"), 90000);
        if (r.code == 401) throw new Exception("Λάθος κλειδί Anthropic. Έλεγξέ το στις Ρυθμίσεις.");
        if (r.code == 400 && r.text().contains("credit")) throw new Exception("Δεν έχεις υπόλοιπο στο Anthropic. Βάλε λίγα δολάρια στο console.anthropic.com.");
        if (r.code >= 400) throw new Exception("Σφάλμα AI (" + r.code + "): " + cut(r.text(), 200));
        JSONObject full = new JSONObject(r.text());
        d("ai_stop", full.optString("stop_reason", ""));
        JSONArray arr = full.optJSONArray("content");
        StringBuilder sb = new StringBuilder();
        if (arr != null) for (int i = 0; i < arr.length(); i++) sb.append(arr.getJSONObject(i).optString("text", ""));
        return sb.toString();
    }

    JSONObject aiIdentify(String jpegB64, String pageTitle) throws Exception {
        JSONObject src = new JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", jpegB64);
        JSONArray content = new JSONArray()
                .put(new JSONObject().put("type", "image").put("source", src))
                .put(new JSONObject().put("type", "text").put("text", AI_PROMPT + (pageTitle == null ? "-" : pageTitle)));
        String txt = claude(content, 600);
        d("ai_raw", cut(txt, 700));
        Matcher m = Pattern.compile("\\{.*\\}", Pattern.DOTALL).matcher(txt);
        if (m.find()) {
            try {
                JSONObject o = new JSONObject(m.group());
                if (o.optString("what_el", "").isEmpty()) {
                    String alt = o.optString("description", o.optString("name", o.optString("title", "")));
                    if (!alt.isEmpty()) o.put("what_el", alt);
                }
                return o;
            } catch (Exception e) {
                d("ai_parse_error", String.valueOf(e.getMessage()));
            }
        }
        String plain = txt.trim().isEmpty() ? "Προϊόν (το AI δεν απάντησε)" : cut(txt.trim(), 120);
        return new JSONObject().put("what_el", plain).put("category", "other").put("weight_kg", 0.5);
    }

    List<String> aiTranslate(List<String> titles) {
        if (titles.isEmpty()) return titles;
        try {
            JSONArray in = new JSONArray();
            for (String t : titles) in.put(t);
            String prompt = "Μετάφρασε κάθε τίτλο προϊόντος σε σύντομο ελληνικό τίτλο (έως 8 λέξεις). "
                    + "Απάντησε ΜΟΝΟ με JSON πίνακα από strings, ίδια σειρά.\n" + in.toString();
            String txt = claude(new JSONArray().put(new JSONObject().put("type", "text").put("text", prompt)), 900);
            Matcher m = Pattern.compile("\\[.*\\]", Pattern.DOTALL).matcher(txt);
            if (!m.find()) return titles;
            JSONArray a = new JSONArray(m.group());
            List<String> out = new ArrayList<>();
            for (int i = 0; i < titles.size(); i++) out.add(i < a.length() ? a.optString(i, titles.get(i)) : titles.get(i));
            return out;
        } catch (Exception e) {
            return titles;
        }
    }

    // ---------------- Apify ----------------
    /** Ανεβάζει τη φωτογραφία στο Apify ώστε να έχει δημόσιο link. null αν δεν γίνεται. */
    String hostImage(byte[] jpg) {
        try {
            Resp s = http("POST", "https://api.apify.com/v2/key-value-stores?name=kina-finder-photos&token=" + enc(apifyToken),
                    new byte[0], null, 30000);
            d("store_http", s.code);
            if (s.code >= 400) { d("store_err", cut(s.text(), 200)); return null; }
            String id = new JSONObject(s.text()).getJSONObject("data").getString("id");
            String key = "p" + System.currentTimeMillis() + ".jpg";
            String base = "https://api.apify.com/v2/key-value-stores/" + id + "/records/" + key;
            Resp put = http("PUT", base + "?token=" + enc(apifyToken), jpg, hdr("Content-Type", "image/jpeg"), 60000);
            d("put_http", put.code);
            if (put.code >= 400) return null;
            Resp chk = http("GET", base, null, null, 20000);
            d("public_http", chk.code);
            return chk.code == 200 ? base : null;
        } catch (Exception e) {
            d("host_error", String.valueOf(e.getMessage()));
            return null;
        }
    }

    JSONArray imageSearch(String imageUrl, String dest) throws Exception {
        JSONObject inp = new JSONObject().put("imageUrl", imageUrl).put("destination", dest)
                .put("language", "en").put("currency", "USD");
        Resp r = http("POST", "https://api.apify.com/v2/acts/" + ACTOR + "/run-sync-get-dataset-items?timeout=120&token=" + enc(apifyToken),
                inp.toString().getBytes(StandardCharsets.UTF_8), hdr("Content-Type", "application/json"), 160000);
        if (r.code == 401) throw new Exception("Λάθος token Apify. Έλεγξέ το στις Ρυθμίσεις.");
        if (r.code == 402 || r.code == 403) throw new Exception("Τελείωσαν τα δωρεάν credits του Apify για αυτόν τον μήνα.");
        if (r.code >= 400) throw new Exception("Σφάλμα αναζήτησης 1688 (" + r.code + "): " + cut(r.text(), 200));
        String t = r.text().trim();
        d("search_" + dest + "_http", r.code);
        d("search_" + dest + "_raw", cut(t, 900));
        if (t.startsWith("[")) return new JSONArray(t);
        JSONObject o = new JSONObject(t);
        JSONArray items = o.optJSONArray("items");
        if (items == null) { JSONObject dd = o.optJSONObject("data"); if (dd != null) items = dd.optJSONArray("items"); }
        return items == null ? new JSONArray() : items;
    }

    // ---------------- Βοηθητικά ----------------
    static String cut(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }

    static String brandHit(String text, String extra) {
        String t = (text == null ? "" : text).toLowerCase(Locale.ROOT);
        List<String> all = new ArrayList<>();
        for (String b : BRANDS) all.add(b);
        if (extra != null && !extra.trim().isEmpty()) all.add(extra.trim().toLowerCase(Locale.ROOT));
        for (String b : all) {
            if (b.matches("[a-z0-9&' .:-]+")) {
                if (Pattern.compile("(?<![a-z])" + Pattern.quote(b) + "(?![a-z])").matcher(t).find()) return b;
            } else if (t.contains(b)) {
                return b;
            }
        }
        return null;
    }

    static Double parsePrice(Object v) {
        if (v instanceof Number) return ((Number) v).doubleValue();
        Matcher m = Pattern.compile("\\d+(?:[.,]\\d+)?").matcher(String.valueOf(v == null ? "" : v));
        return m.find() ? Double.parseDouble(m.group().replace(",", ".")) : null;
    }

    static JSONObject agentLinks(String productUrl) throws Exception {
        JSONObject l = new JSONObject();
        l.put("Superbuy", "https://www.superbuy.com/en/page/buy/?url=" + enc(productUrl == null ? "" : productUrl));
        Matcher m = Pattern.compile("offer/(\\d+)").matcher(productUrl == null ? "" : productUrl);
        if (m.find()) l.put("CSSBuy", "https://www.cssbuy.com/item-1688-" + m.group(1) + ".html");
        return l;
    }

    JSONObject demo() throws Exception {
        String[][] items = {
            {"Ζακέτα φούτερ με κουκούλα και φερμουάρ", "38", "2", "4.8", "12500"},
            {"Βαμβακερή ζακέτα oversize unisex", "45.5", "1", "4.6", "3200"},
            {"Αθλητική ζακέτα με τσέπες, 8 χρώματα", "29.9", "2", "4.4", "8800"},
            {"Ζακέτα fleece χειμερινή", "52", "1", "4.7", "950"}};
        JSONArray res = new JSONArray();
        for (int i = 0; i < items.length; i++) {
            String u = "https://detail.1688.com/offer/6" + i + "88123456" + i + ".html";
            res.put(new JSONObject().put("title", items[i][0]).put("title_orig", items[i][0])
                    .put("price_cny", Double.parseDouble(items[i][1])).put("moq", items[i][2])
                    .put("image", "").put("url", u).put("supplier", "Εργοστάσιο δείγμα " + (i + 1))
                    .put("location", "Guangzhou").put("review", items[i][3]).put("trades", items[i][4])
                    .put("agents", agentLinks(u)));
        }
        JSONObject ai = new JSONObject().put("what_el", "Μαύρη βαμβακερή ζακέτα με κουκούλα (δείγμα)")
                .put("category", "clothes").put("weight_kg", 0.6).put("brand", "");
        return new JSONObject().put("demo", true).put("source_image", "").put("ai", ai).put("results", res)
                .put("removed_branded", 1)
                .put("notice", "Αυτό είναι ΔΕΙΓΜΑ. Βάλε τα 2 κλειδιά στις Ρυθμίσεις για πραγματική αναζήτηση.");
    }

    // ---------------- Κύρια ροή ----------------
    public JSONObject analyze(JSONObject p) throws Exception {
        if (aiKey.isEmpty() || apifyToken.isEmpty()) return demo();

        String link = p.optString("url", "").trim();
        String b64 = p.optString("imageB64", "");
        if (!link.isEmpty() && !link.toLowerCase(Locale.ROOT).startsWith("http")) {
            Matcher m = Pattern.compile("https?://\\S+").matcher(link);
            link = m.find() ? m.group() : "";
        }

        byte[] raw;
        String srcUrl = null, pageTitle = null;
        if (!b64.isEmpty()) {
            int comma = b64.indexOf(',');
            if (b64.startsWith("data:") && comma > 0) b64 = b64.substring(comma + 1);
            raw = Base64.getMimeDecoder().decode(b64);
        } else if (!link.isEmpty()) {
            String[] r = imageFromLink(link);
            srcUrl = r[0];
            pageTitle = r[1];
            Resp ir = http("GET", srcUrl, null, hdr("Accept", "image/*", "Referer", link), 30000);
            if (ir.code >= 400 || ir.body.length == 0) throw new Exception("Δεν κατέβηκε η φωτογραφία (" + ir.code + "). Κάνε screenshot και ανέβασέ το.");
            raw = ir.body;
        } else {
            throw new Exception("Δώσε link ή φωτογραφία.");
        }

        byte[] jpg = img.toJpeg(raw, 1400);
        byte[] thumb = img.toJpeg(raw, 320);
        JSONObject ai = aiIdentify(Base64.getEncoder().encodeToString(jpg), pageTitle);

        String searchUrl = hostImage(jpg);
        if (searchUrl == null) searchUrl = srcUrl;
        if (searchUrl == null) {
            throw new Exception("Δεν ανέβηκε η φωτογραφία για αναζήτηση. Στο apify.com: Settings → Privacy → "
                    + "General resource access → «Anyone with ID can read». Ή στείλε link αντί για φωτογραφία.");
        }

        d("image_url", searchUrl);
        String brand = ai.optString("brand", "").trim();
        JSONArray results = new JSONArray();
        List<String> titles = new ArrayList<>();
        int removed = 0;
        String[] dests = {"1688", "global"};
        for (String dest : dests) {
        if (results.length() > 0) break;
        JSONArray found = imageSearch(searchUrl, dest);
        d("found_" + dest, found.length());
        for (int i = 0; i < found.length() && results.length() < MAX_RESULTS; i++) {
            JSONObject it = found.optJSONObject(i);
            if (it == null) continue;
            String title = it.optString("title", "");
            if (brandHit(title, brand) != null) { removed++; continue; }
            Object pr = it.opt("price");
            if (pr == null) pr = it.opt("priceRange");
            if (pr == null) pr = it.opt("salePrice");
            Double price = parsePrice(pr);
            if (price == null || price <= 0) continue;
            String u = it.optString("productUrl", it.optString("url", ""));
            results.put(new JSONObject().put("title_orig", title).put("price_cny", price)
                    .put("moq", it.opt("minOrderQty")).put("image", it.optString("imageUrl", ""))
                    .put("url", u).put("supplier", it.optString("supplierName", ""))
                    .put("location", it.optString("location", "")).put("review", it.opt("reviewScore"))
                    .put("trades", it.opt("tradeCount")).put("agents", agentLinks(u)));
            titles.add(title);
        }
        }
        List<String> el = aiTranslate(titles);
        for (int i = 0; i < results.length(); i++) results.getJSONObject(i).put("title", el.get(i));

        String notice = "";
        if (!brand.isEmpty()) {
            notice = "Το AI είδε μάρκα «" + brand + "». Δείχνω μόνο παρόμοια χωρίς σήμα: "
                    + "τα επώνυμα στο 1688 είναι απομιμήσεις και κατάσχονται στο τελωνείο.";
        }
        return new JSONObject().put("demo", false)
                .put("source_image", "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(thumb))
                .put("ai", ai).put("results", results).put("removed_branded", removed).put("notice", notice)
                .put("currency", "USD").put("debug", dbg);
    }
}
